import React from "react";
import Nav from "../components/Nav";
import Carousel from "../components/Carousal";
import SuperHero from "../components/Superhero";
import Action from "../components/Action";
import action from "../data/action";
import marvel from "../data/marvel";
import Footer from "../components/Footer";
const Home = () => {
  return (
    <div>
      <Nav />
      <Carousel />
      <Action category={action} />
      <SuperHero category={marvel} />
      <Footer />
    </div>
  );
};

export default Home;
