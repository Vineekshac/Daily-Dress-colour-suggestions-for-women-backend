import React from "react";
import Nav from "../components/Nav";
import action from "../data/action";
import marvel from "../data/marvel";
import { useParams } from "react-router-dom";
import "../components/styles/VideoPlay.css";
import Footer from "../components/Footer";
const VideoPlay = () => {
  const { category, id } = useParams();

  if (category === "action") {
    return (
      <div>
        <Nav />
        <div className="video">
          <iframe
            src={action[id].link}
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowfullscreen
          ></iframe>
          <div className="movie-detailss">
            <p className="desc">{action[id].name}</p>
            <p className="desc">Rating : {action[id].rating} / 5</p>
            <p className="desc">{action[id].desc}</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  } else if (category === "marvel") {
    return (
      <div>
        <Nav />
        <div className="video">
          <iframe
            src={marvel[id].link}
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowfullscreen
          ></iframe>
          <div className="movie-detailss">
            <p className="desc">{marvel[id].name}</p>

            <p className="desc">Rating : {marvel[id].rating} / 5</p>
            <p className="desc">{marvel[id].desc}</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }
};

export default VideoPlay;
