const action = [
    {
        id: 0,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/cvsXj3I9Q2iyyIo95AecSd1tad7.jpg",
        name: "Creed III",
        desc: "After dominating the boxing world, Adonis Creed has been thriving in both his career and family life. When a childhood friend and former boxing prodigy, Damian Anderson, resurfaces after serving a long sentence in prison, he is eager to prove that he deserves his shot in the ring. The face-off between former friends is more than just a fight. To settle the score, Adonis must put his future on the line to battle Damian — a fighter who has",
        rating: "4",
        category: "action",
        link: "https://www.youtube.com/embed/AHmCH7iB_IM",
    }, {
        id: 1,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg",
        name: "John Wick: Chapter 4",
        desc: "With the price on his head ever increasing, John Wick uncovers a path to defeating The High Table. But before he can earn his freedom, Wick must face off against a new enemy with powerful alliances across the globe and forces that turn old friends into foes.",
        rating: "4.5",
        category: "action",
        link: "https://www.youtube.com/embed/qEVUtrk8_B4",
    },
    {
        id: 2,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/3BSxAjiporlwQTWzaHZ9Yrl5C9D.jpg",
        name: "AKA",
        desc: "A steely special ops agent finds his morality put to the test when he infiltrates a crime syndicate and unexpectedly bonds with the boss' young son.",
        rating: "4.1",
        category: "action",
        link: "https://www.youtube.com/embed/044PUmZQd1g",
    },
    {
        id: 3,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/vNVFt6dtcqnI7hqa6LFBUibuFiw.jpg",
        name: "Train to Busan",
        desc: "When a zombie virus pushes Korea into a state of emergency, those trapped on an express train to Busan must fight for their own survival.",
        rating: "4.8",
        category: "action",
        link: "https://www.youtube.com/embed/pyWuHv2-Abk"
    },
    {
        id: 4,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/dHx5yuBb05U9vNaNhIBD7jWyxPk.jpg",
        name: "Sisu",
        desc: "Deep in the wilderness of Lapland, Aatami Korpi is searching for gold but after he stumbles upon Nazi patrol, a breathtaking and gold-hungry chase through the destroyed and mined Lapland wilderness begins.",
        rating: "3.9",
        category: "action",
        link: "https://www.youtube.com/embed/2NnPzpuU5ao"
    },
    {
        id: 5,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/p6yUjhvNGQpFZilKwOKbxQ1eHlo.jpg",
        name: "Renfield",
        desc: "Having grown sick and tired of his centuries as Dracula's lackey, Renfield finds a new lease on life — and maybe even redemption — when he falls for feisty, perennially angry traffic cop Rebecca Quincy.",
        rating: "4.1",
        category: "action",
        link: "https://www.youtube.com/embed/ICydLkeXq3w"
    },
    {
        id: 6,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/m23ltq04OwldiYGmHX8gA4kCtoP.jpg",
        name: "To Catch a Killer",
        desc: "Baltimore. New Year's Eve. A talented but troubled police officer is recruited by the FBI's chief investigator to help profile and track down a mass murderer.",
        rating: "4.2",
        category: "action",
        link: "https://www.youtube.com/embed/WEUX9HwlF5c"
    },
    {
        id: 7,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/8eJf0hxgIhE6QSxbtuNCekTddy1.jpg",
        name: "The Last Kingdom",
        desc: "A show of heroic deeds and epic battles with a thematic depth that embraces politics, religion, warfare, courage, love, loyalty and our universal search for identity. Combining real historical figures and events with fictional characters, it is the story of how a people combined their strength under one of the most iconic kings of history in order to reclaim their land for themselves and build a place they call home.",
        rating: "4.5",
        category: "action",
        link: "https://www.youtube.com/embed/WxPApTGWwas"
    },
    {
        id: 8,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ujr5pztc1oitbe7ViMUOilFaJ7s.jpg",
        name: "PREY",
        desc: "When danger threatens her camp, the fierce and highly skilled Comanche warrior Naru sets out to protect her people. But the prey she stalks turns out to be a highly evolved alien predator with a technically advanced arsenal.",
        category: "action",
        rating: "4.8",
        link: "https://www.youtube.com/embed/1m3Xtveofg0"
    },


]

export default action;

