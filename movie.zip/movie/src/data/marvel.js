const marvel = [
    {
        id: 0,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/c24sv2weTHPsmDa7jEMN0m2P3RT.jpg",
        name: "Spider-Man Home Coming",
        desc: "Following the events of Captain America: Civil War, Peter Parker, with the help of his mentor Tony Stark, tries to balance his life as an ordinary high school student in Queens, New York City, with fighting crime as his superhero alter ego Spider-Man as a new threat, the Vulture, emerges.",
        category: "marvel",
        rating: "5",
        link: "https://youtube.com/embed/rk-dF1lIbIg"
    }, {
        id: 1,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg",
        name: "Avengers Infinity War",
        desc: "As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and use them to inflict his twisted will on all of reality. Everything the Avengers have fought for has led up to this moment - the fate of Earth and existence itself has never been more uncertain.",
        category: "marvel",
        rating: "4",
        link: "https://www.youtube.com/embed/pVxOVlm_lE8"
    },
    {
        id: 2,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/5UsK3grJvtQrtzEgqNlDljJW96w.jpg",
        name: "Batman vs Superman",
        desc: "Fearing the actions of a god-like Super Hero left unchecked, Gotham City’s own formidable, forceful vigilante takes on Metropolis’s most revered, modern-day savior, while the world wrestles with what sort of hero it really needs. And with Batman and Superman at war with one another, a new threat quickly arises, putting mankind in greater danger than it’s ever known before.",
        category: "marvel",
        rating: "3.9",
        link: "https://www.youtube.com/embed/0WWzgGyAH6Y"
    },
    {
        id: 3,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/to0spRl1CMDvyUbOnbb4fTk3VAd.jpg",
        name: "Deadpool 2",
        desc: "Wisecracking mercenary Deadpool battles the evil and powerful Cable and other bad guys to save a boy's life.",
        category: "marvel",
        rating: "4.1",
        link: "https://www.youtube.com/embed/D86RtevtfrA"
    },
    {
        id: 4,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/rg8N7x27Ef6PvlIiioLStf9ZaIO.jpg",
        name: "The Flash",
        desc: "After a particle accelerator causes a freak storm, CSI Investigator Barry Allen is struck by lightning and falls into a coma. Months later he awakens with the power of super speed, granting him the ability to move through Central City like an unseen guardian angel. ",
        category: "marvel",
        rating: "4.2",
        link: "https://www.youtube.com/embed/hebWYacbdvc"
    },
    {
        id: 5,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/pFlaoHTZeyNkG83vxsAJiGzfSsa.jpg",
        name: "Black Adam",
        desc: "Nearly 5,000 years after he was bestowed with the almighty powers of the Egyptian gods—and imprisoned just as quickly—Black Adam is freed from his earthly tomb, ready to unleash his unique form of justice on the modern world.",
        category: "marvel",
        rating: "4.5",
        link: "https://www.youtube.com/embed/X0tOpBuYasI"
    },
    ,
    {
        id: 6,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/KoYWXbnYuS3b0GyQPkbuexlVK9.jpg",
        name: "Supernatural",
        desc: "When they were boys, Sam and Dean Winchester lost their mother to a mysterious and demonic supernatural force. Subsequently, their father raised them to be soldiers. He taught them about the paranormal evil that lives in the dark corners and on the back roads of America ... and he taught them how to kill it. Now, the Winchester brothers crisscross the country in their '67 Chevy Impala, battling every kind of supernatural threat they encounter along the way.",
        category: "marvel",
        rating: "4.6",
        link: "https://www.youtube.com/embed/_hlkNQL5Ecg"
    },
    ,
    {
        id: 7,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/vSNxAJTlD0r02V9sPYpOjqDZXUK.jpg",
        name: "Captain America The First Avenger",
        desc: "During World War II, Steve Rogers is a sickly man from Brooklyn who's transformed into super-soldier Captain America to aid in the war effort. Rogers must stop the Red Skull – Adolf Hitler's ruthless head of weaponry, and the leader of an organization that intends to use a mysterious device of untold powers for world domination.",
        category: "marvel",
        rating: "4.7",
        link: "https://www.youtube.com/embed/qi5UTD7kEr0"
    },
    ,
    {
        id: 8,
        src: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/cj2gWN7TdH1iUG6pUQyqv9N2AXc.jpg",
        name: "Ant-Man",
        desc: "Armed with the astonishing ability to shrink in scale but increase in strength, master thief Scott Lang must embrace his inner-hero and help his mentor, Doctor Hank Pym, protect the secret behind his spectacular Ant-Man suit from a new generation of towering threats. Against seemingly insurmountable obstacles, Pym and Lang must plan and pull off a heist that will save the world.",
        category: "marvel",
        rating: "4.8",
        link: "https://www.youtube.com/embed/pWdKf3MneyI"
    },

]

export default marvel;

