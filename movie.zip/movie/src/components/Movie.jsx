import React from "react";
import Nav from "./Nav";
import "./styles/Movie.css";
import action from "../data/action";
import marvel from "../data/marvel";
import { useParams, Link } from "react-router-dom";
import Footer from "./Footer";
const Movie = () => {
  const { category, id } = useParams();
  if (category === "action") {
    return (
      <div className="containers">
        <Nav />
        <div className="movie-section">
          <img src={action[id].src} height="250px" width="200px" />
          <div className="movie-details">
            <p className="desc">{action[id].name}</p>
            <Link to={`/video/${category}/${id}`} className="button">
              Play Now
            </Link>
            <p className="desc">Rating : {action[id].rating} / 5</p>
            <p className="desc">{action[id].desc}</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  } else if (category === "marvel") {
    return (
      <div className="containers">
        <Nav />
        <div className="movie-section">
          <img src={marvel[id].src} height="250px" width="200px" />
          <div className="movie-details">
            <p className="desc">{marvel[id].name}</p>
            <Link to={`/video/${category}/${id}`} className="button">
              Play Now
            </Link>
            <p className="desc">Rating : {marvel[id].rating} / 5</p>
            <p className="desc">{marvel[id].desc}</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }
};

export default Movie;
