import React from "react";
import "./styles/Action.css";
import { useNavigate, Link } from "react-router-dom";

const SuperHero = (props) => {
  return (
    <div>
      <div className="title">Super Hero</div>
      <div className="Movies-Section">
        <div className="Movies">
          {props.category.map((item, i) => (
            <Link to={`/${item.category}/${i}`}>
              <img src={item.src} height="200px" width="150px" />
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SuperHero;
