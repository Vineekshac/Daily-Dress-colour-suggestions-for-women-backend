import React from "react";
import "./styles/Action.css";
import { Link } from "react-router-dom";

const Action = (props) => {
  return (
    <div>
      <div className="title">Action</div>
      <div className="Movies-Section">
        <div className="Movies">
          {props.category.map((item, i) => (
            <Link to={`/${item.category}/${item.id}`}>
              <img src={item.src} height="200px" width="150px" />
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Action;
