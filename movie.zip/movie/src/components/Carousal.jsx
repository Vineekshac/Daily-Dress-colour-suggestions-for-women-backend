import React from "react";
import "./styles/Carousal.css";
import { useState } from "react";
import { Link } from "react-router-dom";
import action from "../data/action";
import marvel from "../data/marvel";

const Carousel = () => {
  const [image, setImage] = useState(action[0].src);
  const [i, seti] = useState(0);
  const changeImage = () => {
    if (image == action[0].src) {
      seti(1);
      setImage(action[1].src);
    } else {
      seti(0);
      setImage(action[0].src);
    }
  };
  return (
    <div className="container">
      <h1 className="head">Top Movies</h1>
      <div className="carousal">
        <svg
          onClick={changeImage}
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="currentColor"
          className="arrows"
        >
          <path
            fillRule="evenodd"
            d="M11.03 3.97a.75.75 0 010 1.06l-6.22 6.22H21a.75.75 0 010 1.5H4.81l6.22 6.22a.75.75 0 11-1.06 1.06l-7.5-7.5a.75.75 0 010-1.06l7.5-7.5a.75.75 0 011.06 0z"
            clipRule="evenodd"
          />
        </svg>

        <Link to={`/action/${i}`}>
          <img src={image} width="200px"></img>
        </Link>

        <svg
          onClick={changeImage}
          className="arrows"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="currentColor"
        >
          <path
            fillRule="evenodd"
            d="M12.97 3.97a.75.75 0 011.06 0l7.5 7.5a.75.75 0 010 1.06l-7.5 7.5a.75.75 0 11-1.06-1.06l6.22-6.22H3a.75.75 0 010-1.5h16.19l-6.22-6.22a.75.75 0 010-1.06z"
            clipRule="evenodd"
          />
        </svg>
      </div>
    </div>
  );
};

export default Carousel;
